/**
 * @description 密钥常量
 */

module.exports = {
  CRYPTO_SECRET_KEY: "SD123ui_sd$@",
  SESSION_SECRET_KEY: "UIsdf_7878#$"
};
